# Punjab Foods — Website Improvements

Drop-in React components for [punjabfodz.lovable.app](https://punjabfodz.lovable.app).

## Components

| Component | What it does | Priority |
|-----------|-------------|----------|
| `WhatsAppOrderBuilder` | Item picker that pre-fills a WhatsApp order message | 🔴 High |
| `FloatingWhatsApp` | Fixed green button, bottom-right, appears after scroll | 🔴 High |
| `ReviewsSection` | Customer reviews grid with star ratings | 🔴 High |
| `StickyMobileCTA` | Sticky bottom bar (Call + WhatsApp) on mobile only | 🟡 Medium |

## Fonts

Add to your `index.html` `<head>`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;600&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
```

## Quick integration

### 1. Copy components

Copy the `src/components/` folder into your Lovable project's `src/components/` directory.

### 2. Add to your pages

**Homepage (`src/pages/Index.tsx` or similar):**

```tsx
import WhatsAppOrderBuilder from "@/components/WhatsAppOrderBuilder";
import ReviewsSection from "@/components/ReviewsSection";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";
import StickyMobileCTA from "@/components/StickyMobileCTA";

// Inside your page component:
export default function Home() {
  return (
    <>
      {/* ... existing hero, favourites ... */}

      {/* Add order builder after the menu preview section */}
      <WhatsAppOrderBuilder />

      {/* Add reviews before the catering section */}
      <ReviewsSection />

      {/* These render globally — add once, anywhere in the tree */}
      <FloatingWhatsApp />
      <StickyMobileCTA />
    </>
  );
}
```

**Or add to `App.tsx` for global components:**

```tsx
import FloatingWhatsApp from "@/components/FloatingWhatsApp";
import StickyMobileCTA from "@/components/StickyMobileCTA";

export default function App() {
  return (
    <>
      <Router>
        {/* ... your routes ... */}
      </Router>
      <FloatingWhatsApp />
      <StickyMobileCTA />
    </>
  );
}
```

## Customisation

### Update your real founding year

In `src/pages/Index.tsx` (or wherever the hero lives), find:

```
Rawalpindi · Since Years
```

Replace with your actual year, e.g.:

```
Rawalpindi · Since 2008
```

### Update phone numbers / WhatsApp

Search for these values across all components and update if needed:

| Constant | Current value | Location |
|----------|--------------|----------|
| `WA_NUMBER` | `923437117361` | All components |
| `PHONE` | `0515706222` | `StickyMobileCTA.jsx` |

### Swap placeholder reviews

Open `ReviewsSection.jsx` and replace the `REVIEWS` array with real customer testimonials. Each entry needs:

```js
{
  id: 1,
  name: "Customer Name",
  initials: "CN",       // shown in avatar circle
  rating: 5,
  text: "Their review text...",
  item: "What they ordered",
  color: "#1a3a2a",     // avatar background colour
}
```

## File structure

```
src/
└── components/
    ├── WhatsAppOrderBuilder.jsx
    ├── WhatsAppOrderBuilder.css
    ├── FloatingWhatsApp.jsx
    ├── FloatingWhatsApp.css
    ├── ReviewsSection.jsx
    ├── ReviewsSection.css
    ├── StickyMobileCTA.jsx
    └── StickyMobileCTA.css
```
