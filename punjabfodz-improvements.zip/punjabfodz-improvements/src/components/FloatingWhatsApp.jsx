import { useState, useEffect } from "react";
import "./FloatingWhatsApp.css";

const WA_NUMBER = "923437117361";
const WA_DEFAULT_MSG = "Hello! I'd like to place an order at Punjab Foods.";

export default function FloatingWhatsApp() {
  const [visible, setVisible] = useState(false);
  const [pulse, setPulse] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 800);
    const pulseTimer = setTimeout(() => setPulse(false), 5000);
    return () => { clearTimeout(timer); clearTimeout(pulseTimer); };
  }, []);

  const handleClick = () => {
    window.open(
      `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(WA_DEFAULT_MSG)}`,
      "_blank"
    );
  };

  return (
    <button
      className={`fwa-btn ${visible ? "fwa-btn--visible" : ""} ${pulse ? "fwa-btn--pulse" : ""}`}
      onClick={handleClick}
      aria-label="Order on WhatsApp"
      title="Order on WhatsApp"
    >
      <svg className="fwa-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
        <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.555 4.116 1.523 5.847L.057 23.882l6.198-1.438A11.93 11.93 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.88 0-3.645-.49-5.18-1.349l-.371-.22-3.679.852.882-3.573-.241-.379A9.935 9.935 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
      </svg>
      <span className="fwa-label">Order Now</span>
    </button>
  );
}
