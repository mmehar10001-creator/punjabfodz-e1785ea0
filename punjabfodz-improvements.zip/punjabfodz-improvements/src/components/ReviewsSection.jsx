import "./ReviewsSection.css";

const REVIEWS = [
  {
    id: 1,
    name: "Asad Mahmood",
    initials: "AM",
    rating: 5,
    text: "Best pulao in Rawalpindi, hands down. The chicken is always tender and the rice perfectly cooked. Been coming here for years.",
    item: "Chicken Pulao Special",
    color: "#c75b3a",
  },
  {
    id: 2,
    name: "Sana Riaz",
    initials: "SR",
    rating: 5,
    text: "Ordered a 10 kg deg for my brother's nikah. Delivered on time, everyone loved the qorma. Will definitely book again for upcoming events.",
    item: "Catering Deg",
    color: "#1a3a2a",
  },
  {
    id: 3,
    name: "Bilal Chaudhry",
    initials: "BC",
    rating: 5,
    text: "Shami kababs are genuinely homemade quality — soft, spiced just right, not the frozen type you get everywhere else. Highly recommend.",
    item: "Shami Kabab",
    color: "#7c4a1e",
  },
  {
    id: 4,
    name: "Hina Farooq",
    initials: "HF",
    rating: 5,
    text: "Quick delivery, generous portions, and the chicken roast is crispy on the outside and juicy inside. Family favourite now!",
    item: "Chicken Roast",
    color: "#2a5a3a",
  },
  {
    id: 5,
    name: "Umar Siddiqui",
    initials: "US",
    rating: 5,
    text: "The zarda is incredible — not overly sweet, beautiful colour and texture. Ordered with pulao for Eid and everyone was impressed.",
    item: "Zarda + Pulao",
    color: "#854f0b",
  },
];

function Stars({ count = 5 }) {
  return (
    <span className="rev-stars" aria-label={`${count} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <svg
          key={i}
          className={`rev-star ${i < count ? "rev-star--filled" : ""}`}
          viewBox="0 0 16 16"
          fill="currentColor"
          aria-hidden="true"
        >
          <path d="M8 1l1.85 3.75 4.15.6-3 2.92.71 4.13L8 10.25l-3.71 1.95.71-4.13L2 5.35l4.15-.6z" />
        </svg>
      ))}
    </span>
  );
}

export default function ReviewsSection() {
  return (
    <section className="rev-root" aria-label="Customer reviews">
      <div className="rev-header">
        <span className="rev-eyebrow">What our customers say</span>
        <h2 className="rev-title">Loved by Rawalpindi</h2>
        <div className="rev-score">
          <Stars count={5} />
          <span className="rev-score-text">5.0 · Trusted by hundreds of families</span>
        </div>
      </div>

      <div className="rev-grid">
        {REVIEWS.map((r) => (
          <article key={r.id} className="rev-card" aria-label={`Review by ${r.name}`}>
            <Stars count={r.rating} />
            <blockquote className="rev-quote">"{r.text}"</blockquote>
            <footer className="rev-footer">
              <div
                className="rev-avatar"
                style={{ background: r.color }}
                aria-hidden="true"
              >
                {r.initials}
              </div>
              <div>
                <p className="rev-name">{r.name}</p>
                <p className="rev-item">{r.item}</p>
              </div>
            </footer>
          </article>
        ))}
      </div>

      <div className="rev-cta">
        <a
          href="https://wa.me/923437117361?text=I%20wanted%20to%20share%20my%20feedback%20about%20Punjab%20Foods"
          target="_blank"
          rel="noopener noreferrer"
          className="rev-cta-btn"
        >
          Share your experience
        </a>
      </div>
    </section>
  );
}
