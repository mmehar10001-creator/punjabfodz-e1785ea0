import { useState, useMemo } from "react";
import "./WhatsAppOrderBuilder.css";

const MENU = [
  {
    category: "Chicken Pulao",
    items: [
      { id: "cp1", name: "Single", desc: "Rice + chicken, no kabab", price: 430 },
      { id: "cp2", name: "Single Choice", desc: "Rice + chicken + raita or salad", price: 510 },
      { id: "cp3", name: "Single Full", desc: "Rice + chicken + raita + salad + kabab", price: 500 },
      { id: "cp4", name: "Special", desc: "Larger portion, no kabab", price: 580 },
      { id: "cp5", name: "Special Choice", desc: "Larger + raita or salad", price: 670 },
      { id: "cp6", name: "Special Full", desc: "Larger + raita + salad + kabab", price: 650 },
    ],
  },
  {
    category: "Pulao & Sides",
    items: [
      { id: "ps1", name: "Channa Pulao", desc: "Pulao with chickpeas", price: 350 },
      { id: "ps2", name: "Simple Pulao", desc: "Plain rice pulao", price: 280 },
      { id: "ps3", name: "Pulao Kabab", desc: "Pulao served with kabab", price: 350 },
      { id: "ps4", name: "Special Channay", desc: "Full serving of channay", price: 250 },
      { id: "ps5", name: "Salad", desc: "Fresh salad", price: 40 },
      { id: "ps6", name: "Raita", desc: "Yoghurt raita", price: 40 },
    ],
  },
  {
    category: "Roast & Kabab",
    items: [
      { id: "rk1", name: "Chicken Roast – Half", desc: "Half chicken, slow roasted", price: 700 },
      { id: "rk2", name: "Chicken Roast – Full", desc: "Whole chicken, slow roasted", price: 1300 },
      { id: "rk3", name: "Chicken Piece (1/8)", desc: "Single piece", price: 180 },
      { id: "rk4", name: "Shami Kabab", desc: "Per dozen", price: 540 },
    ],
  },
  {
    category: "Sweets & Drinks",
    items: [
      { id: "sd1", name: "Zarda", desc: "Sweet saffron rice", price: 150 },
      { id: "sd2", name: "Soft Drink", desc: "Coke / Nova", price: 80 },
    ],
  },
];

const WA_NUMBER = "923437117361";

export default function WhatsAppOrderBuilder() {
  const [quantities, setQuantities] = useState({});
  const [note, setNote] = useState("");
  const [sent, setSent] = useState(false);

  const change = (id, delta) => {
    setQuantities((q) => {
      const next = Math.max(0, (q[id] || 0) + delta);
      const updated = { ...q };
      if (next === 0) delete updated[id];
      else updated[id] = next;
      return updated;
    });
  };

  const orderLines = useMemo(() => {
    const lines = [];
    for (const cat of MENU) {
      for (const item of cat.items) {
        const qty = quantities[item.id];
        if (qty) lines.push({ ...item, qty, subtotal: qty * item.price });
      }
    }
    return lines;
  }, [quantities]);

  const total = orderLines.reduce((s, l) => s + l.subtotal, 0);
  const itemCount = orderLines.reduce((s, l) => s + l.qty, 0);

  const handleOrder = () => {
    if (!orderLines.length) return;
    const lines = orderLines
      .map((l) => `• ${l.qty}x ${l.name} — Rs. ${l.subtotal.toLocaleString()}`)
      .join("\n");
    const msg =
      `Hello! I'd like to place an order at Punjab Foods.\n\n` +
      `${lines}\n\n` +
      `*Total: Rs. ${total.toLocaleString()}*` +
      (note ? `\n\nNote: ${note}` : "") +
      `\n\nPlease confirm availability and delivery time. Thank you!`;
    const url = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <section className="wob-root" aria-label="Order builder">
      <div className="wob-header">
        <h2 className="wob-title">Build Your Order</h2>
        <p className="wob-sub">Select items — we'll send your order straight to WhatsApp</p>
      </div>

      <div className="wob-body">
        <div className="wob-menu">
          {MENU.map((cat) => (
            <div key={cat.category} className="wob-cat">
              <h3 className="wob-cat-name">{cat.category}</h3>
              {cat.items.map((item) => {
                const qty = quantities[item.id] || 0;
                return (
                  <div key={item.id} className={`wob-item ${qty > 0 ? "wob-item--active" : ""}`}>
                    <div className="wob-item-info">
                      <span className="wob-item-name">{item.name}</span>
                      <span className="wob-item-desc">{item.desc}</span>
                    </div>
                    <div className="wob-item-right">
                      <span className="wob-item-price">Rs. {item.price.toLocaleString()}</span>
                      <div className="wob-qty">
                        <button
                          className="wob-qty-btn"
                          onClick={() => change(item.id, -1)}
                          aria-label={`Remove ${item.name}`}
                          disabled={qty === 0}
                        >−</button>
                        <span className="wob-qty-val">{qty}</span>
                        <button
                          className="wob-qty-btn"
                          onClick={() => change(item.id, 1)}
                          aria-label={`Add ${item.name}`}
                        >+</button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}

          <div className="wob-note">
            <label className="wob-note-label" htmlFor="order-note">Special instructions (optional)</label>
            <textarea
              id="order-note"
              className="wob-note-input"
              placeholder="E.g. extra raita, no onions, delivery address..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <aside className="wob-sidebar" aria-label="Order summary">
          <div className="wob-summary-box">
            <h3 className="wob-summary-title">Your Order</h3>
            {orderLines.length === 0 ? (
              <p className="wob-empty">No items yet — add something from the menu</p>
            ) : (
              <>
                <ul className="wob-summary-list">
                  {orderLines.map((l) => (
                    <li key={l.id} className="wob-summary-line">
                      <span className="wob-summary-qty">{l.qty}×</span>
                      <span className="wob-summary-name">{l.name}</span>
                      <span className="wob-summary-sub">Rs. {l.subtotal.toLocaleString()}</span>
                    </li>
                  ))}
                </ul>
                <div className="wob-total-row">
                  <span>Total</span>
                  <span className="wob-total-val">Rs. {total.toLocaleString()}</span>
                </div>
              </>
            )}

            <button
              className={`wob-send-btn ${sent ? "wob-send-btn--sent" : ""}`}
              onClick={handleOrder}
              disabled={!orderLines.length || sent}
              aria-label="Send order via WhatsApp"
            >
              {sent ? (
                <>✓ Opening WhatsApp…</>
              ) : (
                <>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                    <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.555 4.116 1.523 5.847L.057 23.882l6.198-1.438A11.93 11.93 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.88 0-3.645-.49-5.18-1.349l-.371-.22-3.679.852.882-3.573-.241-.379A9.935 9.935 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
                  </svg>
                  Send via WhatsApp
                  {itemCount > 0 && <span className="wob-badge">{itemCount}</span>}
                </>
              )}
            </button>
            <p className="wob-disclaimer">Opens WhatsApp with your order pre-filled</p>
          </div>
        </aside>
      </div>
    </section>
  );
}
