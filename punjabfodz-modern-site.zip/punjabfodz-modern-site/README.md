# PunjabFodz Modern Website

## Run locally

npm install
npm run dev

## Upload to GitHub

1. Create new repository
2. Upload all files
3. Connect with Vercel or Netlify
