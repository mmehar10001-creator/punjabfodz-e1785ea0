export default function App() {
  const items = [
    {
      name: "Zinger Burger",
      price: "Rs 699",
      img: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1200&auto=format&fit=crop"
    },
    {
      name: "Cheese Pizza",
      price: "Rs 1299",
      img: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=1200&auto=format&fit=crop"
    },
    {
      name: "Shawarma Roll",
      price: "Rs 499",
      img: "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?q=80&w=1200&auto=format&fit=crop"
    }
  ];

  return (
    <div>
      <nav className="navbar">
        <h1>PunjabFodz</h1>

        <div className="nav-links">
          <a href="#menu">Menu</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </div>

        <button>Order Now</button>
      </nav>

      <section className="hero">
        <div>
          <h2>Fresh Taste Delivered Fast 🍔</h2>
          <p>
            Modern fast food restaurant website with premium light theme.
          </p>
          <button className="hero-btn">View Menu</button>
        </div>

        <img
          src="https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=1200&auto=format&fit=crop"
          alt="Burger"
        />
      </section>

      <section id="menu" className="menu">
        <h2>Popular Menu</h2>

        <div className="grid">
          {items.map((item, i) => (
            <div className="card" key={i}>
              <img src={item.img} alt={item.name} />

              <div className="card-content">
                <h3>{item.name}</h3>
                <p>{item.price}</p>
                <button>Add To Cart</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="about" className="about">
        <h2>About PunjabFodz</h2>
        <p>
          We provide delicious food with fast delivery and premium quality.
        </p>
      </section>

      <footer id="contact">
        <h3>Contact Us</h3>
        <p>Punjab, Pakistan</p>
        <p>+92 300 1234567</p>
      </footer>
    </div>
  );
}
