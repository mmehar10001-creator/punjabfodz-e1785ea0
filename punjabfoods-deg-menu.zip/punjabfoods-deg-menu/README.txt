Punjab Foods Deg Menu Website

Open index.html in browser

Upload to GitHub:
1. Create repository
2. Upload files
3. Connect with Vercel / Netlify
